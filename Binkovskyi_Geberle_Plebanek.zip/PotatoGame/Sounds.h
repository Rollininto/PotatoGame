#pragma once
class Sounds {
public:
	static enum {
		SE_COIN,
		SE_JUMP,
		SE_DEATH,
		SE_DOOR,
		SE_TOTAL
	};
};